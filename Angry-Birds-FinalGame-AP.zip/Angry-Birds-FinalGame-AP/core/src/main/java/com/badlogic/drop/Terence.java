package com.badlogic.drop;

import com.badlogic.gdx.graphics.Texture;

public class Terence extends Bird{
    public Terence(Texture texture, float x, float y, float width, float height) {
        super(texture, x, y, width, height);
    }
}
