package com.badlogic.drop;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;

import java.io.*;

public class state implements Serializable {
    private static final long serialVersionUID = 1L;

    // Serializable fields
    public static int level = 1;
    public static float level1score = 0;
    public static float level2score = 0;
    public static float level3score = 0;
    public static boolean level1flag = false;
    public static boolean level2flag = false;
    public static boolean level3flag = false;

    // Singleton-like instance for state management
    private static state currentState;

    // Private constructor to prevent direct instantiation
    private state() {}

    public static synchronized state getCurrentState() {
        if (currentState == null) {
            currentState = loadState("game_state.ser");
            if (currentState == null) {
                currentState = new state(); // Initialize with default state if file doesn't exist
            }
        }
        return currentState;
    }

    // Save the current state to a file
    public static void saveState(String filePath) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            // Create a new state object with current static values
            state stateToSave = new state();
            stateToSave.level = level;
            stateToSave.level1score = level1score;
            stateToSave.level2score = level2score;
            stateToSave.level3score = level3score;
            stateToSave.level1flag = level1flag;
            stateToSave.level2flag = level2flag;
            stateToSave.level3flag = level3flag;

            // Write the state object
            oos.writeObject(stateToSave);
            Gdx.app.log("State", "State saved successfully!");
        } catch (IOException e) {
            Gdx.app.error("State", "Failed to save state: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Load the state from a file
    public static state loadState(String filePath) {
        FileHandle file = Gdx.files.local(filePath); // Using LibGDX file handling

        // If save file doesn't exist, return null
        if (!file.exists()) {
            Gdx.app.log("State", "No saved state file found.");
            return null;
        }

        try (ObjectInputStream ois = new ObjectInputStream(file.read())) {
            // Directly read the state object
            state loadedState = (state) ois.readObject();

            // Update static fields with loaded values
            level = loadedState.level;
            level1score = loadedState.level1score;
            level2score = loadedState.level2score;
            level3score = loadedState.level3score;
            level1flag = loadedState.level1flag;
            level2flag = loadedState.level2flag;
            level3flag = loadedState.level3flag;

            Gdx.app.log("State"+ level, "State loaded successfully!");

            return loadedState;

        } catch (IOException | ClassNotFoundException e) {
            Gdx.app.error("State", "Failed to load state: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // Reset the game state
    public static void resetState() {
        level = 1;
        level1score = 0;
        level2score = 0;
        level3score = 0;
        level1flag = false;
        level2flag = false;
        level3flag = false;
        saveState("game_state.ser");
    }

    // Debug method to print current state
    public static void printCurrentState() {
        Gdx.app.log("State", "Current Game State:");
        Gdx.app.log("State", "Level: " + level);
        Gdx.app.log("State", "Level 1 Score: " + level1score);
        Gdx.app.log("State", "Level 1 Completed: " + level1flag);
    }
}
