package com.badlogic.drop;
import com.badlogic.gdx.graphics.Texture;

public class Pig2 extends Pig {

     public Pig2(Texture texture,float x, float y,float width,float height) {
        super(texture,x, y,width, height);
    }
}
