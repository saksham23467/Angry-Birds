package com.badlogic.drop;

import com.badlogic.gdx.graphics.Texture;

public class Pig3 extends Pig {

     public Pig3(Texture texture, float x, float y, float width, float height) {
        super(texture, x, y, width, height);
    }
}
