package com.badlogic.drop;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

public class Pig1 extends Pig {
    public Texture texture;
    public Rectangle bounds;


    public Pig1(Texture texture, float x, float y, float width, float height) {
        super(texture, x, y, width, height);
        this.texture = texture;
        this.bounds = new Rectangle(x, y, width, height);
    }

    public void updateBounds(float x, float y) {
        bounds.setPosition(x, y);
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void dispose() {
        if (texture != null) {
            texture.dispose();
        }


    }
}

