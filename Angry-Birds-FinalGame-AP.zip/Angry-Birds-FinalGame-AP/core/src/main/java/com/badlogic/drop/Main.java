package com.badlogic.drop;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.io.File;
import java.io.FileOutputStream;
import java.util.logging.Level;

public class Main extends Game {
    public homescreen homeScreen;
    public gamescreen gameScreen;
    public Screen settingsscreen;
    public Screen levelOneScreen;
    public Screen leveltwoScreen;
    public Screen levelThreeScreen;
    public Screen winscreen;
     public Camera camera;
     public Screen losecreen;
     public SpriteBatch batch;
    public BitmapFont font;
    public Screen levelscreen;


    @Override
    public void create() {
//        state.loadState("game_state.ser");

        homeScreen = new homescreen(this);
        gameScreen = new gamescreen(this);
        settingsscreen = new settingsscreen(this);
        levelOneScreen = new level1(this);
        winscreen= new winscreen(this);
        losecreen= new losescreen(this);
        leveltwoScreen= new leveltwo(this);
        levelThreeScreen=new level3(this);
        levelscreen = new LevelScreen(this);
        batch = new SpriteBatch();
        font = new BitmapFont();


        setScreen(homeScreen);
    }

    @Override
    public void dispose() {
        super.dispose();

        homeScreen.dispose();
        gameScreen.dispose();
        settingsscreen.dispose();
        levelOneScreen.dispose();
        winscreen.dispose();
        losecreen.dispose();
        leveltwoScreen.dispose();
        levelThreeScreen.dispose();
        levelscreen.dispose();

    }


}
