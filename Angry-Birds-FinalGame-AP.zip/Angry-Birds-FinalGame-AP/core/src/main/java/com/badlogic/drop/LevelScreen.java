package com.badlogic.drop;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class LevelScreen implements Screen {
    private final Main game;
    private Texture bgtexture;

    private SpriteBatch spriteBatch;
    private FitViewport viewport;
    Music music;
    Button back;
    private Button play;
    Button Level1;
    Button Level2;
    private Button Level3;


    private Button settings;
    private Button vol;
    boolean isMusicPlaying=true;
    Texture vontexture;
    private Texture vofftexture;
    private Texture level1texture;
    private Texture level2texture;
    private Texture level3texture;

    public LevelScreen(Main game) {
        this.game=game;
        spriteBatch=new SpriteBatch( );
        viewport=new FitViewport(8, 5);
        bgtexture=new Texture(Gdx.files.internal("leels.png"));

        music=Gdx.audio.newMusic(Gdx.files.internal("angry_birds_theme.mp3"));
        music.setLooping(true);
        music.setVolume(0.1f );

        vontexture=new Texture(Gdx.files.internal("volumeon.png"));
        vofftexture=new Texture(Gdx.files.internal("volumeoff.png"));

        level1texture=new Texture(Gdx.files.internal("image.png"));
        level2texture=new Texture(Gdx.files.internal("image2.png"));
        level3texture=new Texture(Gdx.files.internal("image3.png"));


        Texture backTexture=new Texture(Gdx.files.internal("backy.png"));
        Texture playTexture=new Texture (Gdx.files.internal("PLAY.png"));
        Texture settingsTexture=new Texture(Gdx.files.internal("settings.png"));
        Level1 = new Button(level1texture, 1f, 2, 1.9f, 1.5f, viewport);
        Level2 = new Button(level2texture, 3.05f, 2, 1.9f, 1.5f, viewport);
        Level3 = new Button(level3texture, 5.1f, 2, 1.9f, 1.5f, viewport);

        back=new Button(backTexture,0 ,4,1,1,viewport );
        play=new Button(playTexture,3.05f,2 ,1.9f ,1.5f,viewport);
        settings=new Button(settingsTexture,7,0,0.8f,0.7f,viewport);
        vol= new Button(vontexture,0, 0,0.8f,0.7f,viewport);
//        state.loadState("game_state.ser");



    }

    @Override
    public void show() {
//
//        state.loadState("game_state.ser");

//        state.loadState("Save_File.ser"); // Load saved state when this screen becomes active

        if (isMusicPlaying&&!music.isPlaying()) {
            music.play();
        }
    }

    @Override
    public void render(float delta) {

        viewport.apply();
        spriteBatch.setProjectionMatrix(viewport.getCamera().combined);
        spriteBatch.begin();
        spriteBatch.draw(bgtexture,0,0,8,5);


        back.render(spriteBatch);
        Level1.render(spriteBatch);
        Level2.render(spriteBatch);
        Level3.render(spriteBatch);

        settings.render(spriteBatch);
        Texture cvt;
        if(isMusicPlaying) {
            cvt=vontexture;
        }
        else {
            cvt=vofftexture;
        }
        spriteBatch.draw(cvt,vol.getX(),vol.getY(),vol.getWidth(),vol.getHeight());
        spriteBatch.end();
//        state.loadState("Save_File.ser"); // Load saved state when this screen becomes active


        handle();
    }

    void handle() {
//        state.loadState("Save_File.ser");

        if(back.isTouched()) {
            music.stop();
            game.setScreen(game.homeScreen);
        }
        if(Level1.isTouched()) {
            game.levelOneScreen=new level1(game);
            game.setScreen(game.levelOneScreen);
        }
        if(Level2.isTouched()) {
            if (state.getCurrentState().level >1 ) {

//
//
                game.leveltwoScreen = new leveltwo(game);
                game.setScreen(game.leveltwoScreen);
            }
        }
        if(Level3.isTouched()) {
            if (state.getCurrentState().level > 2) {
                state.level3flag = true; // Mark level 3 as completed
                state.saveState("Save_File.ser"); // Save state after level progression
                game.levelThreeScreen = new level3(game);
                game.setScreen(game.levelThreeScreen);
            }
        }

        if(settings.isTouched()) {
            if(game.settingsscreen==null) {
                game.settingsscreen=new settingsscreen(game);
            }
            game.setScreen(game.settingsscreen);
        }
        if(vol.isTouched()) {
            toggle();
        }
        if(Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            state.saveState("game_state.ser");  // Load the state when the game starts

            Gdx.app.exit();
            music.stop();
        }
    }

    void toggle() {
        isMusicPlaying=!isMusicPlaying;
        if (isMusicPlaying) {
            music.play();
        }
        else {
            music.stop();
        }
    }

    @Override
    public void resize(int width,int height) {
        viewport.update(width,height,true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {
        if(music.isPlaying()) {
            music.stop();
        }
    }

    @Override
    public void dispose() {
        spriteBatch.dispose();
        if(bgtexture!=null) bgtexture.dispose();
        if(music!=null) music.dispose();
        back.dispose();
        play.dispose();
        settings.dispose();
        vol.dispose();
        level1texture.dispose();
        level2texture.dispose();
        level3texture.dispose();


        if(vontexture!=null) vontexture.dispose();
        if(vofftexture!=null) vofftexture.dispose();



    }

    public void setSpriteBatch(SpriteBatch spriteBatch) {
    }
}
