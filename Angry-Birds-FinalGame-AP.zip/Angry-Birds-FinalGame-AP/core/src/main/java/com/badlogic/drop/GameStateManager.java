package com.badlogic.drop;

import java.io.*;

public class GameStateManager implements Serializable {
    private static final long serialVersionUID = 1L;

    // Singleton instance
    private static GameStateManager instance;

    // Game state variables
    private int currentLevel = 1;
    private float level1Score = 0;
    private float level2Score = 0;
    private float level3Score = 0;
    private boolean level1Completed = false;
    private boolean level2Completed = false;
    private boolean level3Completed = false;

    // Default save file path
    private static final String DEFAULT_SAVE_FILE = "game_state.ser";

    // Private constructor
    private GameStateManager() {}

    // Singleton method with improved error handling
    public static synchronized GameStateManager getInstance() {
        if (instance == null) {
            try {
                instance = loadState(DEFAULT_SAVE_FILE);
            } catch (Exception e) {
                System.out.println("Error loading saved state. Creating new game state.");
                instance = new GameStateManager();
            }
        }
        return instance;
    }

    // Save game state
    public void saveState() {
        saveState(DEFAULT_SAVE_FILE);
    }

    // Save game state to specific file
    public void saveState(String filePath) {
        try (FileOutputStream fos = new FileOutputStream(filePath);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {

            oos.writeObject(this);
            System.out.println("Game state saved successfully to " + filePath);
        } catch (IOException e) {
            System.err.println("Error saving game state: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Load game state from file
    private static GameStateManager loadState(String filePath) {
        File saveFile = new File(filePath);

        // If save file doesn't exist, return a new instance
        if (!saveFile.exists()) {
            System.out.println("No saved game state found. Starting a new game.");
            return new GameStateManager();
        }

        try (FileInputStream fis = new FileInputStream(saveFile);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            Object loadedObject = ois.readObject();

            if (loadedObject instanceof GameStateManager) {
                System.out.println("Game state loaded successfully from " + filePath);
                return (GameStateManager) loadedObject;
            } else {
                System.out.println("Invalid save file. Starting a new game.");
                return new GameStateManager();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading game state: " + e.getMessage());
            e.printStackTrace();
            return new GameStateManager();
        }
    }

    // Getters and setters
    public int getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel(int level) {
        this.currentLevel = level;
        saveState(); // Auto-save on level change
    }

    public float getLevel1Score() {
        return level1Score;
    }

    public void setLevel1Score(float score) {
        this.level1Score = score;
        saveState(); // Auto-save on score change
    }

    // Add similar methods for other state variables...

    // Method to reset game state
    public void resetGameState() {
        currentLevel = 1;
        level1Score = 0;
        level2Score = 0;
        level3Score = 0;
        level1Completed = false;
        level2Completed = false;
        level3Completed = false;
        saveState();
    }

    // Debug method to print current state
    public void printCurrentState() {
        System.out.println("Current Game State:");
        System.out.println("Level: " + currentLevel);
        System.out.println("Level 1 Score: " + level1Score);
        System.out.println("Level 1 Completed: " + level1Completed);
    }
}
