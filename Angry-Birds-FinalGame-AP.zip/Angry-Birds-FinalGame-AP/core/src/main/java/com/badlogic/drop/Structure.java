package com.badlogic.drop;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public interface Structure {

    Rectangle getBounds();


    void render(SpriteBatch batch);

    float getX();
    float getY();
    float getWidth();
    float getHeight();

    void dispose();
}
