package com.badlogic.drop;//package com.badlogic.drop;

import com.badlogic.drop.homescreen;
import com.badlogic.gdx.backends.headless.HeadlessApplication;
import com.badlogic.gdx.backends.headless.HeadlessApplicationConfiguration;
import com.badlogic.gdx.ApplicationListener;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertTrue;

public class HomeScreenTest {

    private homescreen homeScreen;
    private Main game;

    @Before
    public void setUp() {
        HeadlessApplicationConfiguration config = new HeadlessApplicationConfiguration();
        new HeadlessApplication(new ApplicationListener() {
            @Override
            public void create() {
            }

            @Override
            public void resize(int width, int height) {
            }

            @Override
            public void render() {
            }

            @Override
            public void pause() {
            }

            @Override
            public void resume() {
            }

            @Override
            public void dispose() {
            }
        }, config);
        Main game = new Main();
        homeScreen = new homescreen(game);
    }

    @Test
    public void testTransitionToGameScreen() {
        homeScreen.show();
        assertTrue(homeScreen.music.isPlaying());
    }

    @Test
    public void testMusicPlaysOnShow() {
        homeScreen.show();
        assertTrue(homeScreen.music.isPlaying());
    }

    @After
    public void tearDown() {
        if (homeScreen != null) {
            homeScreen.dispose();
        }
    }
}

