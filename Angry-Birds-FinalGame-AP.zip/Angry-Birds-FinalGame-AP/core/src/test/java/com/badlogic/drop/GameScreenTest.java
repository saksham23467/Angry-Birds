package com.badlogic.drop;

import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;

public class GameScreenTest {
    private Main game;
    private gamescreen gameScreen;

    @Before
    public void setUp() {
        game = new Main();
        gameScreen = new gamescreen(game);
    }

    @Test
    public void testToggleMusic() {
        assertTrue(gameScreen.isMusicPlaying);
        gameScreen.toggle();
        assertFalse(gameScreen.isMusicPlaying);
        gameScreen.toggle();
        assertTrue(gameScreen.isMusicPlaying);
    }

    @Test
    public void testBackToHomeScreen() {
        gameScreen.handle();
        gameScreen.back.isTouched(); // Simulate touching the back button
        assertTrue(game.getScreen() instanceof homescreen);
    }
}
