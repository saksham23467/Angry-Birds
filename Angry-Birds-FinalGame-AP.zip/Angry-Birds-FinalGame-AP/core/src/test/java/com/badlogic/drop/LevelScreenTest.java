package com.badlogic.drop;

import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Matrix4;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class LevelScreenTest {

    private LevelScreen levelScreen;
    private Main mockGame;
    private Music mockMusic;
    private Button mockButton;

    private GL20 glMock;

    @Before
    public void setUp() {
        glMock = mock(GL20.class);

        SpriteBatch spriteBatch = mock(SpriteBatch.class);
        when(spriteBatch.getProjectionMatrix()).thenReturn(new Matrix4());

        levelScreen = new LevelScreen(new Main());
        levelScreen.setSpriteBatch(spriteBatch);
    }
    @Test
    public void testRendering() {
        levelScreen.render(0.16f);

        verify(glMock).glCreateShader(anyInt());
    }



    @Test
    public void testMusicToggleOn() {
        levelScreen.isMusicPlaying = true;

        levelScreen.toggle();

        verify(mockMusic, times(1)).stop();
        verify(mockMusic, times(1)).play();
        assertFalse(levelScreen.isMusicPlaying);
    }

    @Test
    public void testMusicToggleOff() {
        levelScreen.isMusicPlaying = false;

        levelScreen.toggle();

        verify(mockMusic, times(1)).stop();
        verify(mockMusic, times(1)).play();
        assertTrue(levelScreen.isMusicPlaying);
    }

    @Test
    public void testBackButtonPressed() {
        when(mockButton.isTouched()).thenReturn(true);
        levelScreen.back = mockButton;

        levelScreen.handle();

        verify(mockGame, times(1)).setScreen(mockGame.homeScreen);
        verify(mockMusic, times(1)).stop(); // Music should stop
    }

    @Test
    public void testLevel1ButtonPressed() {
        when(mockButton.isTouched()).thenReturn(true);
        levelScreen.Level1 = mockButton;

        levelScreen.handle();
        verify(mockGame, times(1)).setScreen(mockGame.levelOneScreen);
    }




    @Test
    public void testLevel2NotAccessibleIfLevel1NotCompleted() {
        when(state.getCurrentState().level).thenReturn(1);

        when(mockButton.isTouched()).thenReturn(true);
        levelScreen.Level2 = mockButton;
        levelScreen.handle();

        verify(mockGame, never()).setScreen(mockGame.leveltwoScreen);
    }
}
