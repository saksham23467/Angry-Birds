package com.badlogic.drop;

import com.badlogic.drop.*;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.FitViewport;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Level1Test {

    private level1 level1;

    @BeforeEach
    void setUp() {
        Main game = new Main();
        level1 = new level1(game);
    }

    @Test
    void testInitialSetup() {
        assertNotNull(level1);
        assertNotNull(level1.getPig1());
    }

    @Test
    void testPauseButtonPress() {

        level1.handle();
        assertTrue(level1.isPaused);
    }

}
